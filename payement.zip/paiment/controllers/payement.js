const axios = require("axios")
module.exports = {
    Add: async (req,res)=>{
        const url = "developers.flouci.com/api/generate_payement"
        const payload = {
            "app_token": "2987ec15-8edb-4855-9672-c2a6295c9e61",
            "app_secret": process.env.FLOUCI_SECRET,
            "amount ": req.body.amount,
            "accept_card": "true",
            "session_timeout_secs": 1200,
            "success_link": "http://localhost:5000/success",
            "fail_link":"http://localhost:5000/fail",
            "developer_tracking_id":"1c891bcc-85c3-417a-b6a9-3686d4d42720"
 
        }
         await axios
          .post(url,payload)
          .then(result=> {
            result.send(result.data)

          } )
          .catch(err => console.error(err));
        
       
    },
    verify : async (req,res)=> {
        const id_payement= req.params.id
        const url = `https://developers.flouci.com/api/verify_payment/${id_payement}`
        await axios.get(url,
            headers = {
                "content-Type": "application/json",
                "apppublic" : "2987ec15-8edb-4855-9672-c2a6295c9e61",
                "appsecret" : process.env.FLOUCI_SECRET
            })
         .then(result=>{
            res.send(result.data)
         })
         .catch(err=>{
            console.log(err.message)
         })
    }
}