const express = require ("express");
const { Add, verify } = require("../controllers/payement");
const Router = express.Router();


Router.post("/payment",Add)
Router.post("/payement/:id",verify)

module.exports=Router